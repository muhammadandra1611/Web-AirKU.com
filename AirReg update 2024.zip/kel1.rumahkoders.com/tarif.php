  <?php 
   if (isset($_POST["submit_tarif"])) {
    $id_tarif = htmlspecialchars($_POST["id_tarif"]);
    $tipe_tarif = htmlspecialchars($_POST["tipe_tarif"]);
    $tarif = htmlspecialchars($_POST["tarif"]);
    $status = htmlspecialchars($_POST["status"]);
 

    // Koneksi ke database
    $koneksi= mysqli_connect("localhost", "rumahko5_AirKu", "Sepakbola123", "rumahko5_kel1");

    // Periksa koneksi
    if (!$koneksi) {
        die("Koneksi gagal: " . mysqli_connect_error());
    }

    // Query untuk memasukkan data ke dalam tabel
    $query = "INSERT INTO tb_tarif (id_tarif, tipe_tarif, tarif, status) VALUES ('$id_tarif', '$tipe_tarif', '$tarif', '$status')";

    // Jalankan query
    if (mysqli_query($koneksi, $query)) {
        header('location:bendahara.php');
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

    // Tutup koneksi
    mysqli_close($conn);
} else {
    echo "Data gagal";
    header('location:tambah?tambah_tr.php');
}
?>