
<?php 
require 'koneksi.php';
session_start();

if (empty($_POST["username"]) || empty($_POST["password"])) {
    header('location:index.php?error=missing_fields');
    exit();
}

$username = mysqli_real_escape_string($koneksi, $_POST["username"]);

// Prepare SQL statement to check if the user exists
$cek_user = mysqli_prepare($koneksi, "SELECT * FROM tuser WHERE username = ?");
if ($cek_user) {
    mysqli_stmt_bind_param($cek_user, "s", $username);
    mysqli_stmt_execute($cek_user);
    $result = mysqli_stmt_get_result($cek_user);
    $user_valid = mysqli_fetch_assoc($result);
    
    if ($user_valid) {
        $hashed_password = $user_valid["password"];

        if (password_verify($_POST["password"], $hashed_password)) {
            // Set session variables
            $_SESSION["username"] = $user_valid["username"];
            $_SESSION['nama'] = $user_valid['nama'];

            // Redirect based on username
            if ($username === "andra") {
                header('location:admin.php?id='.$_SESSION["username"]);
                exit();
            } elseif ($username === "petugas") {
                header('location:petugas.php?id='.$_SESSION["username"]);
                exit();
            } elseif ($username === "bendahara") {
                header('location:bendahara.php?id='.$_SESSION["username"]);
                exit();
            } else {
                header('location:warga.php?id='.$_SESSION["username"]);
                exit();
            }
        } else {
            // Password incorrect
            header('location:index.php?pw=incorrect');
            exit();
        }
    } else {
        // User not found
        header('location:index.php?error=user_not_found');
        exit();
    }
} else {
    // SQL statement preparation failed
    header('location:index.php?error=server_error');
    exit();
}
?>
