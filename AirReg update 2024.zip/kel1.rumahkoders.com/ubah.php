<?php 
$server ="localhost";
$user ="rumahko5_AirKu";
$password="Sepakbola123";
$database="rumahko5_kel1";

$koneksi = mysqli_connect($server, $user, $password, $database) or die(mysqli_error($koneksi));

// Mengambil id dari URL
$id = $_GET["ubah"];



// Memeriksa apakah form telah disubmit
if(isset($_POST["submit"])){
    $nama = htmlspecialchars($_POST["nama"]);
    $nik = htmlspecialchars($_POST["nik"]);
    $alamat = htmlspecialchars($_POST["alamat"]);
    $kota = htmlspecialchars($_POST["kota"]);
    $no_hp = htmlspecialchars($_POST["no_hp"]);
    $email = htmlspecialchars($_POST["email"]);

    // Query UPDATE untuk mengubah data berdasarkan id
    $query = "UPDATE tb_warga SET nama='$nama', nik='$nik', alamat='$alamat', kota='$kota', no_hp='$no_hp', email='$email' WHERE id= $id";
    mysqli_query($koneksi, $query);

    echo "<script>
            alert('Data berhasil diubah');
            document.location.href='admin.php';
          </script>";
}

// Mengambil data warga yang akan diubah
$query_data = "SELECT * FROM tb_warga WHERE id=$id";
$result = mysqli_query($koneksi, $query_data);
$mhs = mysqli_fetch_assoc($result);

// Memeriksa apakah data ditemukan
if (!$mhs) {
    echo "<script>
            alert('Data tidak ditemukan');
            document.location.href='admin.php';
          </script>";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Ubah Data Warga</title>
</head>
 <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
<body>
    <form action="" method="POST">
        <!-- Menambahkan nilai awal dari data yang akan diubah -->
        <label for="nama">Nama:</label>
        <input type="text" id="nama" name="nama" value="<?php echo $mhs['nama']; ?>" required>

        <label for="nik">Nik:</label>
        <input type="text" id="nik" name="nik" value="<?php echo $mhs['nik']; ?>" required>

        <label for="alamat">Alamat:</label>
        <input type="text" id="alamat" name="alamat" value="<?php echo $mhs['alamat']; ?>" required>

        <label for="kota">Kota:</label>
        <input type="text" id="kota" name="kota" value="<?php echo $mhs['kota']; ?>" required>

        <label for="no_hp">No hp:</label>
        <input type="text" id="no_hp" name="no_hp" value="<?php echo $mhs['no_hp']; ?>" required>

        <label for="email">Email:</label>
        <input type="text" id="email" name="email" value="<?php echo $mhs['email']; ?>" required>

        <button type="submit" name="submit">Ubah</button>
    </form>
</body>
</html>
