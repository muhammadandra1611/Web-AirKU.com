<?php
// Database connection
$koneksi = mysqli_connect("localhost", "rumahko5_AirKu", "Sepakbola123", "rumahko5_kel1");

// Check connection
if ($koneksi->connect_error) {
    die("Connection failed: " . $koneksi->connect_error);
}

// Query to get data from tb_warga
$sql = "SELECT id, nama FROM tb_warga";
$result = $koneksi->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input, select {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <?php if (isset($_GET["tambah_tr"])) { ?>
        <form action="tarif.php" method="POST">
            <label for="id_tarif">id_tarif:</label>
            <input type="text" id="id_tarif" name="id_tarif" required>

            <label for="tipe_tarif">tipe_tarif:</label>
            <input type="text" id="tipe_tarif" name="tipe_tarif" required>

            <label for="tarif">tarif:</label>
            <input type="text" id="tarif" name="tarif" required>

            <label for="status">Status:</label>
            <select class="form-select" id="status" name="status" required>
                <option value="" disabled selected>Pilih status</option>
                <option value="Aktif">Aktif</option>
                <option value="Tidak Aktif">Tidak Aktif</option>
            </select>

            <button type="submit" name="submit_tarif">Tambah</button>
        </form>
    <?php } elseif (isset($_GET["tambah_mt"])) { ?>
        <form action="meter.php" method="POST">
            <label for="nama_pelanggan">Nama Pelanggan:</label>
            <select id="nama_pelanggan" name="nama_pelanggan" required>
                <?php
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . $row["nama"] . '">' . $row["nama"] . '</option>';
                    }
                } else {
                    echo '<option value="">No data available</option>';
                }
                ?>
            </select>

            <label for="meter_awal">Meter Awal:</label>
            <input type="text" id="meter_awal" name="meter_awal" required>

            <label for="meter_akhir">Meter Akhir:</label>
            <input type="text" id="meter_akhir" name="meter_akhir" required>

            <label for="pemakaian">Pemakaian:</label>
            <input type="text" id="pemakaian" name="pemakaian" required>

            <label for="tanggal_waktu">Tanggal & Waktu:</label>
            <input type="datetime-local" id="tanggal_waktu" name="tanggal_waktu">

            <label for="petugas_pencatat">Petugas Pencatat:</label>
            <input type="text" id="petugas_pencatat" name="petugas_pencatat" required>

            <button type="submit" name="submit_mt">Tambah</button>
        </form>
    <?php } else { ?>
        <form action="proses.php" method="POST">
            <label for="nama">Nama:</label>
            <input type="text" id="nama" name="nama" required>

            <label for="nik">Nik:</label>
            <input type="text" id="nik" name="nik" required>

            <label for="alamat">Alamat:</label>
            <input type="text" id="alamat" name="alamat" required>

            <label for="kota">Kota:</label>
            <input type="text" id="kota" name="kota" required>

            <label for="no_hp">No hp:</label>
            <input type="text" id="no_hp" name="no_hp" required>

            <label for="email">Email:</label>
            <input type="text" id="email" name="email" required>

            <button type="submit" name="submit">Tambah</button>
        </form>
    <?php } ?>
</body>
</html>

<?php
// Close the database connection
$koneksi->close();
?>
