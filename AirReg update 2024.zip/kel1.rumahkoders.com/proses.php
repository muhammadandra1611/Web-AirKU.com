<?php 
if (isset($_POST["submit"])) {
    $nama = htmlspecialchars($_POST["nama"]);
    $nik = htmlspecialchars($_POST["nik"]);
    $alamat = htmlspecialchars($_POST["alamat"]);
    $kota = htmlspecialchars($_POST["kota"]);
    $no_hp = htmlspecialchars($_POST["no_hp"]);
    $email = htmlspecialchars($_POST["email"]);

    // Koneksi ke database
    $koneksi= mysqli_connect("localhost", "rumahko5_AirKu", "Sepakbola123", "rumahko5_kel1");

    // Periksa koneksi
    if (!$koneksi) {
        die("Koneksi gagal: " . mysqli_connect_error());
    }

    // Query untuk memasukkan data ke dalam tabel
    $query = "INSERT INTO tb_warga (nama, nik, alamat, kota, no_hp, email) VALUES ('$nama', '$nik', '$alamat', '$kota', '$no_hp', '$email')";

    // Jalankan query
    if (mysqli_query($koneksi, $query)) {
        header('location:admin.php');
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

    // Tutup koneksi
    mysqli_close($conn);
} else {
    echo "Data gagal";
    header('location:tambah.php');
}




?>
