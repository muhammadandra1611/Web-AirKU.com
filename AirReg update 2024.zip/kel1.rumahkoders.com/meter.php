<?php 
if (isset($_POST["submit_mt"])) {
    $Nama_Pelanggan = htmlspecialchars($_POST["nama_pelanggan"]);
    $Meter_Awal = htmlspecialchars($_POST["meter_awal"]);
    $Meter_Akhir = htmlspecialchars($_POST["meter_akhir"]);
    $Pemakaian = htmlspecialchars($_POST["pemakaian"]);
    $Tanggal_Waktu = htmlspecialchars($_POST["tanggal_waktu"]);
    $Petugas_Pencatat = htmlspecialchars($_POST["petugas_pencatat"]);

    // Koneksi ke database
   $koneksi=mysqli_connect("localhost","rumahko5_AirKu","Sepakbola123","rumahko5_kel1");

    // Periksa koneksi
    if (!$koneksi) {
        die("Koneksi gagal: " . mysqli_connect_error());
    }

    // Query untuk memasukkan data ke dalam tabel
    $query = "INSERT INTO tb_meter (nama_pelanggan, meter_awal, meter_akhir, pemakaian,tanggal_waktu, petugas_pencatat) VALUES ('$Nama_Pelanggan', '$Meter_Awal', ' $Meter_Akhir', ' $Pemakaian', '  $Tanggal_Waktu', '  $Petugas_Pencatat')";

    // Jalankan query
    if (mysqli_query($koneksi, $query)) {
        header('location:petugas.php?userr=data_pemakaian');
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

    // Tutup koneksi
    mysqli_close($conn);
} else {
    echo "Data gagal";
    header('location:tambah.php');
}






?>
