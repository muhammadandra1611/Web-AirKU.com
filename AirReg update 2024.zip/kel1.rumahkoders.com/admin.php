<?php
require 'koneksi.php';
require 'function.php';
$query="SELECT * FROM tb_warga";
$a=mysqli_query($koneksi,$query);
session_start();

// Logout jika tombol logout ditekan
if (isset($_POST["logout"])) {
    session_unset();
    session_destroy();
    header("location:index.php");
    exit();
}
$q = "SELECT * FROM tuser WHERE username = '".$_SESSION['username']."'";
$l = mysqli_query($koneksi, $q);
$p = mysqli_fetch_assoc($l);
$id = $p["id"];


if (isset($_SESSION["username"]) && $_SESSION["username"]==="petugas") {
     header('location:petugas.php?id='.$_SESSION["username"]);
}elseif (isset($_SESSION["username"]) && $_SESSION["username"]==="bendahara") {
     header('location:bendahara.php?id='.$_SESSION["username"]);
}elseif (isset($_SESSION["username"])) {
      if ($id>=6) {
     header('location:warga.php?id='.$_SESSION["username"]);
        }

}


if (!isset($_SESSION["username"])) {
     header("location:index.php");
     exit();
}

$warga = query("SELECT * FROM tb_warga");


//tombol cari
if (isset($_POST["cari"])) {
    $warga=cari($_POST["keyword"]);
}


$qwy = "SELECT * FROM tb_komplain";
$stmt = mysqli_prepare($koneksi, $qwy);
if ($stmt) {
    mysqli_stmt_execute($stmt);
    $komplain = mysqli_stmt_get_result($stmt);
    if (mysqli_num_rows($komplain) > 0) {
        $pi = mysqli_fetch_assoc($komplain);
        $komplen = $pi["id"];
    } else {
        echo "Data komplain tidak ditemukan";
    }
} else {
    echo "Kesalahan saat menyiapkan statement";
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>AirKu.COM</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Modal -->
<!-- <div class="modal" tabindex="-1" role="dialog" id="exampleModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Kelompok Andra&Deni</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Andra:sebagai Backend</p>
        <p>Deni:Bug Analysis</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
      
      </div>
    </div>
  </div>
</div> -->
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <div class="sidebar pe-4 pb-3">
            <nav class="navbar bg-light navbar-light">
                <a href="index.html" class="navbar-brand mx-4 mb-3">
                    <h3 class="text-primary"><!-- <i class="fa fa-hashtag me-2"> --></i>AirKu.COM</h3>
                </a>




                <div class="d-flex align-items-center ms-4 mb-4">
                    <div class="position-relative">
                        <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                        <div class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1"></div>
                    </div>
                    <div class="ms-3">
                        <h6 class="mb-0"><?php echo $_SESSION["username"];?></h6>
                        <span><?php 

                            if (isset($_SESSION["username"])) {
                                echo "ADMIN";
                                }


                        ?></span>
                    </div>
                </div>
                <div class="navbar-nav w-100">
                    <a href="admin.php?user=dashboard" class="nav-item nav-link active"><i class="fa fa-tachometer-alt me-2"></i>Management user</a>
      

                    <a href="admin.php?userr=data_pemakaian" class="nav-item nav-link"><i class="fa fa-th me-2"></i>Data pemakaian</a>
                    <a href="admin.php?user_lihat" class="nav-item nav-link"><i class="fa fa-keyboard me-2"></i>Lihat komplain</a>
                    <a href="admin.php?tabel" class="nav-item nav-link"><i class="fa fa-table me-2"></i>Tables</a>
                    <a href="admin.php?chart" class="nav-item nav-link"><i class="fa fa-chart-bar me-2"></i>Charts</a>
                 
                </div>
            </nav>
        </div>
        <!-- Sidebar End -->

 <?php if(isset($_GET["tabel"])){ ?>
 
 <?php echo "<script>alert('Belum Ada Kontennya hehe:)')</script>" ?>
 


 
 <?php }elseif(isset($_GET["chart"])){  ?>
 <?php echo "<script>alert('Belum Ada Kontennya hehe:)')</script>" ?>
 
 <?php } ?>
        <!-- Content Start -->
        <?php if(isset($_GET["userr"])){ ?>
        <div class="content">
            
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>
                <form class="d-none d-md-flex ms-4">
                       <input type="text" name="keyword" class="form-control me-2" type="search" placeholder="Search" aria-label="Search" autofocus autocomplete="off">
                         <button class="btn btn-outline-success" type="submit" name="cari">Search</button>
                </form>
                <div class="navbar-nav align-items-center ms-auto">
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-envelope me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Message</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                 <!--    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div> -->
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                  <!--   <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div> -->
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                   <!--  <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div> -->
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all message</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-bell me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Notificatin</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Profile updated</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">New user added</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Password changed</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all notifications</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <img class="rounded-circle me-lg-2" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                            <span class="d-none d-lg-inline-flex"><?php echo $_SESSION["username"]; ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="admin.php?profile" class="dropdown-item">My Profile</a>
                            <a href="#" class="dropdown-item">Settings</a>
                            <a href="logout.php" class="dropdown-item" name="logout">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>
            <!-- Navbar End -->


                 <div class="row" id="summary">
    <?php
    // Mengambil total volume pemakaian dari tabel tb_meter
    $qm = "SELECT SUM(pemakaian) AS total_volume FROM tb_meter";
    $meter = mysqli_query($koneksi, $qm);

    // Periksa apakah query berhasil
    if ($meter) {
        $rm = mysqli_fetch_assoc($meter);
        $total_volume = isset($rm['total_volume']) ? $rm['total_volume'] : 0;

        // Menampilkan total volume pemakaian air
        echo '<div class="col-xl-3 col-md-6">';
        echo '    <div class="card bg-primary text-white mb-4">';
        echo '        <div class="card-body d-flex justify-content-center">';
        echo '            <h1 class="text-center">' . htmlspecialchars($total_volume) . '</h1>';
        echo '            <div class="ms-2"><sup>m3</sup></div>';
        echo '        </div>';
        echo '        <div class="card-footer d-flex align-items-center justify-content-between">';
        echo '            <div class="mx-auto">Total Volume Pemakaian Air</div>';
        echo '        </div>';
        echo '    </div>';
        echo '</div>';
    } else {
        // Tampilkan pesan kesalahan jika query gagal
        echo '<div class="col-xl-3 col-md-6">';
        echo '    <div class="card bg-danger text-white mb-4">';
        echo '        <div class="card-body d-flex justify-content-center">';
        echo '            <h1 class="text-center">Error</h1>';
        echo '            <div class="ms-2"><sup>m3</sup></div>';
        echo '        </div>';
        echo '        <div class="card-footer d-flex align-items-center justify-content-between">';
        echo '            <div class="mx-auto">Failed to retrieve data</div>';
        echo '        </div>';
        echo '    </div>';
        echo '</div>';
    }

    // Mengambil total pelanggan dari tabel tb_warga
    $query_total_warga = "SELECT COUNT(*) as total FROM tb_warga";
    $result_total_warga = mysqli_query($koneksi, $query_total_warga);
    $total_rows = 0;

    if ($result_total_warga) {
        $row = mysqli_fetch_assoc($result_total_warga);
        $total_rows = isset($row['total']) ? $row['total'] : 0;
    }

    // Menampilkan total pelanggan
    echo '<div class="col-xl-3 col-md-6">';
    echo '    <div class="card bg-warning text-white mb-4">';
    echo '        <div class="card-body d-flex justify-content-center">';
    echo '            <h1 class="text-center">' . htmlspecialchars($total_rows) . '</h1>';
    echo '            <div class="ms-2"><strong> orang</strong></div>';
    echo '        </div>';
    echo '        <div class="card-footer d-flex align-items-center justify-content-between">';
    echo '            <div class="mx-auto">Total Pelanggan</div>';
    echo '        </div>';
    echo '    </div>';
    echo '</div>';

    // Mengambil jumlah pelanggan yang sudah dicatat
    $query_sudah_dicatat = "
        SELECT COUNT(DISTINCT nama_pelanggan) AS total_sudah_dicatat
        FROM tb_meter
        WHERE petugas_pencatat IS NOT NULL
    ";
    $result_sudah_dicatat = mysqli_query($koneksi, $query_sudah_dicatat);

    if ($result_sudah_dicatat) {
        $sudah_dicatat = mysqli_fetch_assoc($result_sudah_dicatat)['total_sudah_dicatat'];
    } else {
        $sudah_dicatat = 0; // Atau bisa gunakan pesan kesalahan: "Error fetching data"
    }

    // Menghitung jumlah pelanggan yang belum dicatat
    $belum_dicatat = $total_rows - $sudah_dicatat;

    // Menampilkan jumlah pelanggan yang sudah dicatat
    echo '
    <div class="col-xl-3 col-md-6">
        <div class="card bg-success text-white mb-4">
            <div class="card-body d-flex justify-content-center">
                <h1 class="text-center">' . htmlspecialchars($sudah_dicatat) . '</h1>
                <div class="ms-2">Pelanggan</div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <div class="mx-auto">Sudah Dicatat</div>
            </div>
        </div>
    </div>
    ';

    // Menampilkan jumlah pelanggan yang belum dicatat
    echo '
    <div class="col-xl-3 col-md-6">
        <div class="card bg-danger text-white mb-4">
            <div class="card-body d-flex justify-content-center">
                <h1 class="text-center">' . htmlspecialchars($belum_dicatat) . '</h1>
                <div class="ms-2">Pelanggan</div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <div class="mx-auto">Belum Dicatat</div>
            </div>
        </div>
    </div>
    ';

    // Menutup koneksi
    $koneksi->close();
    ?>
</div>

<!--</div>-->
<!--<div class="row" id="chart">-->
<!--    <div class="col-xl-6">-->
<!--        <div class="card mb-4">-->
<!--            <div class="card-header">-->
<!--                <i class="fas fa-chart-area me-1"></i>-->
<!--                Area Chart Example-->
<!--            </div>-->
<!--            <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>-->
<!--        </div>-->
<!--    </div>-->
<!--    <div class="col-xl-6">-->
<!--        <div class="card mb-4">-->
<!--            <div class="card-header">-->
<!--                <i class="fas fa-chart-bar me-1"></i>-->
<!--                Bar Chart Example-->
<!--            </div>-->
<!--            <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->




            <!-- Recent Sales Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-light text-center rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                    	 <td><a class="btn btn-sm btn-primary" href="">Tambah</a></td>
                        <h6 class="mb-0">Tabel user AirKU.com</h6>

                        <a href="">Show All</a>
                    </div>
                    <div class="table-responsive">
                                                              <table class="table text-start align-middle table-bordered table-hover mb-0">
                            <thead>
                                <tr class="text-dark">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">Alamat</th>
                                    <th scope="col">Kota</th>
                                    <th scope="col">No Hanphone</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                           		  <?php
				  	while ($p=mysqli_fetch_assoc($a)) {
				  	


				    ?>
                                <tr>
                                    <td><input class="form-check-input" type="checkbox"></td>
                                    <td><?php echo $p["nama"]?></td>
                                    <td><?php echo $p["alamat"]?></td>
                                    <td><?php echo $p["kota"]?></td>
                                    <td><?php echo $p["no_hp"]?></td>
                                  	<td><?php echo $p["email"]?></td>
                                  	<td><a class="btn btn-sm btn-primary" href="ubah.php?ubah=<?php echo $p["id"]; ?>">Edit</a></td>
 <td><a class="btn btn-sm btn-dark" href="hapus.php?hapus=<?php echo $p["id"]; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a></td>


                                
                      
                                </tr>
                               
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Recent Sales End -->


          


            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-light rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#">AirKU.com</a>, All Right Reserved. 
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                            Designed By <a href="https://htmlcodex.com">AirKU.com</a>
                        </br>
                     <!--    Distributed By <a class="border-bottom" href="https://themewagon.com" target="_blank">ThemeWagon</a> -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>
       <?php }elseif(isset($_GET["user_lihat"])){ ?>

        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>
                <form class="d-none d-md-flex ms-4">
                       <input type="text" name="keyword" class="form-control me-2" type="search" placeholder="Search" aria-label="Search" autofocus autocomplete="off">
                       <button class="btn btn-outline-success" type="submit" name="cari">Search</button>
                </form>
                <div class="navbar-nav align-items-center ms-auto">
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-envelope me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Message</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                 <!--    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div> -->
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                  <!--   <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div> -->
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                   <!--  <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div> -->
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all message</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-bell me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Notificatin</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Profile updated</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">New user added</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Password changed</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all notifications</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <img class="rounded-circle me-lg-2" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                            <span class="d-none d-lg-inline-flex"><?php echo $_SESSION["username"]; ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">My Profile</a>
                            <a href="#" class="dropdown-item">Settings</a>
                            <a href="logout.php" class="dropdown-item" name="logout">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>
            <!-- Navbar End -->


           



            <!-- Recent Sales Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-light text-center rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                    	 <td><a class="btn btn-sm btn-primary" href="">Tambah</a></td>
                        <h6 class="mb-0">Tabel user AirKU.com</h6>

                        <a href="">Show All</a>
                    </div>
                    <div class="table-responsive">
                                       <table class="table text-start align-middle table-bordered table-hover mb-0">
                            <thead>
                                <tr class="text-dark">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">nama</th>
                                    <th scope="col">Keluhan</th>
                                 
                                </tr>
                            </thead>
                            <tbody>
                 <?php while ($p=mysqli_fetch_assoc($a)) { ?>
                
                                <tr>
                                    <td><input class="form-check-input" type="checkbox"></td>
                                    <td><?php echo $pi["nama"]?></td>
                                    <td><?php echo $pi["keluhan"]?></td>
                     
 <td><a class="btn btn-sm btn-dark" href="hapus.php?hapus_tarif=<?php echo $p["id"]; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a></td>


                                
                      
                                </tr>
                               
                <?php }?>     
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Recent Sales End -->


          


            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-light rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#">AirKU.com</a>, All Right Reserved. 
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                            Designed By <a href="https://htmlcodex.com">AirKU.com</a>
                        </br>
                     <!--    Distributed By <a class="border-bottom" href="https://themewagon.com" target="_blank">ThemeWagon</a> -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>

       <?php }else{ ?>
       	   <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>
                <form class="d-none d-md-flex ms-4" >
                       <input type="text" name="keyword" class="form-control me-2" type="search" placeholder="Search" aria-label="Search" autofocus autocomplete="off">
                       <button class="btn btn-outline-success" type="submit" name="cari">Search</button>
                </form>
                <div class="navbar-nav align-items-center ms-auto">
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-envelope me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Message</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                 <!--    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div> -->
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                  <!--   <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div> -->
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                   <!--  <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div> -->
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all message</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-bell me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Notificatin</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Profile updated</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">New user added</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Password changed</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all notifications</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <img class="rounded-circle me-lg-2" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                            <span class="d-none d-lg-inline-flex"><?php echo $_SESSION["username"]; ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="admin.php?profile" class="dropdown-item">My Profile</a>
                            <a href="admin.php?setting" class="dropdown-item">Settings</a>
                            <a href="logout.php" class="dropdown-item" name="logout">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>
            <!-- Navbar End -->


           
<!-- my profile andra -->
<?php if (isset($_GET["profile"])) { ?>
<h2><center>Profil Akun Saya</center></h2>
 <div class="container-fluid pt-4 px-4">
<center><img src="https://pluralsight.imgix.net/paths/path-icons/c-plus-plus-93c7ddd5cc.png" class="img-thumbnail" alt="c++" width="100px" height="100px"></center>
</div>
<br>
  <div class="form-control">
  <div class="mb-3 row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Nama</label>
    <div class="col-sm-10">
      <input type="text" readonly class="form-control-plaintext"  value="Muhammad Sakti Noviandra">
    </div>
  </div>
    <div class="mb-3 row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
    <div class="col-sm-10">
      <input type="text" readonly class="form-control-plaintext"  value="andrahoax@gmail.com">
    </div>
  </div>
    <div class="mb-3 row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Hobby</label>
    <div class="col-sm-10">
      <input type="text" readonly class="form-control-plaintext"  value="Reverse Engineering">
    </div>
  </div>
    <div class="mb-3 row">
    <label for="staticEmail" class="col-sm-2 col-form-label">No Hp</label>
    <div class="col-sm-10">
      <input type="text" readonly class="form-control-plaintext"  value="085156420506">
    </div>
  </div>
<div class="mb-3 row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Hak Akses</label>
    <div class="col-sm-10">
      <input type="text" readonly class="form-control-plaintext"  value="Admin">
    </div>
  </div>
</div>

<?php }elseif(isset($_GET["setting"])){?>
<h1>Belum ada apa-apa disini hehe
    <?php }else{ ?>
  <div class="row" id="summary">
    <?php
    // Mengambil total volume pemakaian dari tabel tb_meter
    $qm = "SELECT SUM(pemakaian) AS total_volume FROM tb_meter";
    $meter = mysqli_query($koneksi, $qm);

    // Periksa apakah query berhasil
    if ($meter) {
        $rm = mysqli_fetch_assoc($meter);
        $total_volume = isset($rm['total_volume']) ? $rm['total_volume'] : 0;

        // Menampilkan total volume pemakaian air
        echo '<div class="col-xl-3 col-md-6">';
        echo '    <div class="card bg-primary text-white mb-4">';
        echo '        <div class="card-body d-flex justify-content-center">';
        echo '            <h1 class="text-center">' . htmlspecialchars($total_volume) . '</h1>';
        echo '            <div class="ms-2"><sup>m3</sup></div>';
        echo '        </div>';
        echo '        <div class="card-footer d-flex align-items-center justify-content-between">';
        echo '            <div class="mx-auto">Total Volume Pemakaian Air</div>';
        echo '        </div>';
        echo '    </div>';
        echo '</div>';
    } else {
        // Tampilkan pesan kesalahan jika query gagal
        echo '<div class="col-xl-3 col-md-6">';
        echo '    <div class="card bg-danger text-white mb-4">';
        echo '        <div class="card-body d-flex justify-content-center">';
        echo '            <h1 class="text-center">Error</h1>';
        echo '            <div class="ms-2"><sup>m3</sup></div>';
        echo '        </div>';
        echo '        <div class="card-footer d-flex align-items-center justify-content-between">';
        echo '            <div class="mx-auto">Failed to retrieve data</div>';
        echo '        </div>';
        echo '    </div>';
        echo '</div>';
    }

    // Mengambil total pelanggan dari tabel tb_warga
    $query_total_warga = "SELECT COUNT(*) as total FROM tb_warga";
    $result_total_warga = mysqli_query($koneksi, $query_total_warga);
    $total_rows = 0;

    if ($result_total_warga) {
        $row = mysqli_fetch_assoc($result_total_warga);
        $total_rows = isset($row['total']) ? $row['total'] : 0;
    }

    // Menampilkan total pelanggan
    echo '<div class="col-xl-3 col-md-6">';
    echo '    <div class="card bg-warning text-white mb-4">';
    echo '        <div class="card-body d-flex justify-content-center">';
    echo '            <h1 class="text-center">' . htmlspecialchars($total_rows) . '</h1>';
    echo '            <div class="ms-2"><strong> orang</strong></div>';
    echo '        </div>';
    echo '        <div class="card-footer d-flex align-items-center justify-content-between">';
    echo '            <div class="mx-auto">Total Pelanggan</div>';
    echo '        </div>';
    echo '    </div>';
    echo '</div>';

    // Mengambil jumlah pelanggan yang sudah dicatat
    $query_sudah_dicatat = "
        SELECT COUNT(DISTINCT nama_pelanggan) AS total_sudah_dicatat
        FROM tb_meter
        WHERE petugas_pencatat IS NOT NULL
    ";
    $result_sudah_dicatat = mysqli_query($koneksi, $query_sudah_dicatat);

    if ($result_sudah_dicatat) {
        $sudah_dicatat = mysqli_fetch_assoc($result_sudah_dicatat)['total_sudah_dicatat'];
    } else {
        $sudah_dicatat = 0; // Atau bisa gunakan pesan kesalahan: "Error fetching data"
    }

    // Menghitung jumlah pelanggan yang belum dicatat
    $belum_dicatat = $total_rows - $sudah_dicatat;

    // Menampilkan jumlah pelanggan yang sudah dicatat
    echo '
    <div class="col-xl-3 col-md-6">
        <div class="card bg-success text-white mb-4">
            <div class="card-body d-flex justify-content-center">
                <h1 class="text-center">' . htmlspecialchars($sudah_dicatat) . '</h1>
                <div class="ms-2">Pelanggan</div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <div class="mx-auto">Sudah Dicatat</div>
            </div>
        </div>
    </div>
    ';

    // Menampilkan jumlah pelanggan yang belum dicatat
    echo '
    <div class="col-xl-3 col-md-6">
        <div class="card bg-danger text-white mb-4">
            <div class="card-body d-flex justify-content-center">
                <h1 class="text-center">' . htmlspecialchars($belum_dicatat) . '</h1>
                <div class="ms-2">Pelanggan</div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <div class="mx-auto">Belum Dicatat</div>
            </div>
        </div>
    </div>
    ';

    // Menutup koneksi
    $koneksi->close();
    ?>
</div>

<!--</div>-->
<!--<div class="row" id="chart">-->
<!--    <div class="col-xl-6">-->
<!--        <div class="card mb-4">-->
<!--            <div class="card-header">-->
<!--                <i class="fas fa-chart-area me-1"></i>-->
<!--                Area Chart Example-->
<!--            </div>-->
<!--            <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>-->
<!--        </div>-->
<!--    </div>-->
<!--    <div class="col-xl-6">-->
<!--        <div class="card mb-4">-->
<!--            <div class="card-header">-->
<!--                <i class="fas fa-chart-bar me-1"></i>-->
<!--                Bar Chart Example-->
<!--            </div>-->
<!--            <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->



            <!-- Recent Sales Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-light text-center rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                    	 <td><a href="tambah.php" class="btn btn-sm btn-primary" href="">Tambah</a></td>
                        <h6 class="mb-0">Tabel user AirKU.com</h6>

                        <a href="">Show All</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table text-start align-middle table-bordered table-hover mb-0">
                            <thead>
                                <tr class="text-dark">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">Alamat</th>
                                    <th scope="col">Kota</th>
                                    <th scope="col">No Hanphone</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                           		  <?php
				  	while ($p=mysqli_fetch_assoc($a)) {
				  	


				    ?>
                                <tr>
                                    <td><input class="form-check-input" type="checkbox"></td>
                                    <td><?php echo $p["nama"]?></td>
                                    <td><?php echo $p["alamat"]?></td>
                                    <td><?php echo $p["kota"]?></td>
                                    <td><?php echo $p["no_hp"]?></td>
                                  	<td><?php echo $p["email"]?></td>
                                  	<td><a class="btn btn-sm btn-primary" href="ubah.php?ubah=<?php echo $p["id"]; ?>">Edit</a></td>
 <td><a class="btn btn-sm btn-dark" href="hapus.php?hapus=<?php echo $p["id"]; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a></td>


                                
                      
                                </tr>
                               
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Recent Sales End -->


          


            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-light rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#">AirKU.com</a>, All Right Reserved. 
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                            Designed By <a href="https://htmlcodex.com">AirKU.com</a>
                        </br>
                     <!--    Distributed By <a class="border-bottom" href="https://themewagon.com" target="_blank">ThemeWagon</a> -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>

<?php } ?>
<?php } ?>

        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script >
        // Set timeout untuk menampilkan modal setelah redirect
// setTimeout(function() {
//   var myModal = new bootstrap.Modal(document.getElementById('exampleModal'));
  
//   myModal.show();

// }, 1000); // 5000 milidetik = 5 detik



    </script>
</body>

</html>