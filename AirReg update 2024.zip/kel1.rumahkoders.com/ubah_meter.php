<?php
// Database connection
$koneksi = mysqli_connect("localhost", "rumahko5_AirKu", "Sepakbola123", "rumahko5_kel1");

// Check connection
if ($koneksi->connect_error) {
    die("Connection failed: " . $koneksi->connect_error);
}

// Mengambil id dari URL
$ubah_meter = $_GET["ubah_meter"];

// Memeriksa apakah form telah disubmit
if (isset($_POST["submit_meter"])) {
    $nama_pelanggan = mysqli_real_escape_string($koneksi, $_POST["nama_pelanggan"]);
    $meter_awal = mysqli_real_escape_string($koneksi, $_POST["meter_awal"]);
    $meter_akhir = mysqli_real_escape_string($koneksi, $_POST["meter_akhir"]);
    $pemakaian = mysqli_real_escape_string($koneksi, $_POST["pemakaian"]);
    $tanggal_waktu = mysqli_real_escape_string($koneksi, $_POST["tanggal_waktu"]);
    $petugas_pencatat = mysqli_real_escape_string($koneksi, $_POST["petugas_pencatat"]);

    // Query UPDATE untuk mengubah data berdasarkan id
    $query = "UPDATE tb_meter SET nama_pelanggan='$nama_pelanggan', meter_awal='$meter_awal', meter_akhir='$meter_akhir', pemakaian='$pemakaian', tanggal_waktu='$tanggal_waktu', petugas_pencatat='$petugas_pencatat' WHERE id=$ubah_meter";
    if (mysqli_query($koneksi, $query)) {
        echo "<script>
                alert('Data berhasil diubah');
                document.location.href='petugas.php?userr=data_pemakaian';
              </script>";
    } else {
        echo "Error updating record: " . mysqli_error($koneksi);
    }
}

// Mengambil data meter yang akan diubah
$query_data = "SELECT * FROM tb_meter WHERE id=$ubah_meter";
$result = mysqli_query($koneksi, $query_data);
$tr = mysqli_fetch_assoc($result);

// Memeriksa apakah data ditemukan
if (!$tr) {
    echo "<script>
            alert('Data tidak ditemukan');
            document.location.href='petugas.php?userr=data_pemakaian';
          </script>";
    exit;
}

// Mengambil data dari tb_warga untuk dropdown
$query_warga = "SELECT id, nama FROM tb_warga";
$result_warga = mysqli_query($koneksi, $query_warga);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Ubah Data Meter</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input, select {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
            background-color: #ecf0f1;
            border: 1px solid #bdc3c7;
            border-radius: 4px;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <form action="" method="POST">
        <label for="nama_pelanggan">Nama Pelanggan:</label>
        <select id="nama_pelanggan" name="nama_pelanggan" required>
            <?php
            if ($result_warga->num_rows > 0) {
                while($row_warga = $result_warga->fetch_assoc()) {
                    $selected = $tr['nama_pelanggan'] == $row_warga['nama'] ? 'selected' : '';
                    echo '<option value="' . $row_warga["nama"] . '" ' . $selected . '>' . $row_warga["nama"] . '</option>';
                }
            } else {
                echo '<option value="">No data available</option>';
            }
            ?>
        </select>

        <label for="meter_awal">Meter Awal:</label>
        <input type="text" id="meter_awal" name="meter_awal" value="<?php echo $tr['meter_awal']; ?>" required>

        <label for="meter_akhir">Meter Akhir:</label>
        <input type="text" id="meter_akhir" name="meter_akhir" value="<?php echo $tr['meter_akhir']; ?>" required>

        <label for="pemakaian">Pemakaian:</label>
        <input type="text" id="pemakaian" name="pemakaian" value="<?php echo $tr['pemakaian']; ?>" required>

        <label for="tanggal_waktu">Tanggal & Waktu:</label>
        <input type="datetime-local" id="tanggal_waktu" name="tanggal_waktu" value="<?php echo date('Y-m-d\TH:i', strtotime($tr['tanggal_waktu'])); ?>" required>

        <label for="petugas_pencatat">Petugas Pencatat:</label>
        <input type="text" id="petugas_pencatat" name="petugas_pencatat" value="<?php echo $tr['petugas_pencatat']; ?>" required>

        <button type="submit" name="submit_meter">Ubah</button>
    </form>
</body>
</html>

<?php
// Close the database connection
$koneksi->close();
?>
