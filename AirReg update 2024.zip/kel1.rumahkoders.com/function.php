<?php

/*$conn = mysqli_connect("localhost", "rumahko5_AirKu", "Sepakbola123", "rumahko5_kel1");*/

$server ="localhost";
$user ="rumahko5_AirKu";
$password="Sepakbola123";
$database="rumahko5_kel1";

$koneksi=mysqli_connect($server,$user,$password,$database) or die(mysqli_error($koneksi));

function query($query)
{
    global $koneksi;
    $result = mysqli_query($koneksi, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

/*function hapus($id)
{
    global $conn;
    mysqli_query($conn, "DELETE FROM mahasiswa WHERE id=$id");
    return mysqli_affected_rows($conn);
}

function ubah($data)
{
    global $conn;

    if (isset($_POST["submit"])) {
        $id = $data["id"];
        $nrp = htmlspecialchars($_POST["nrp"]);
        $nama = htmlspecialchars($_POST["nama"]);
        $email = htmlspecialchars($_POST["email"]);
        $jurusan = htmlspecialchars($_POST["jurusan"]);

        // upload gambar
        $gambar = upload();
        if (!$gambar) {
            return false;
        }

        $query = "UPDATE mahasiswa SET
            nrp='$nrp',
            nama='$nama',
            email='$email',
            jurusan='$jurusan',
            gambar='$gambar'
            WHERE id=$id;
        ";

        mysqli_query($conn, $query);

        echo "<script>
            alert('Data Telah Diubah');
            document.location.href='index.php';
        </script>";

        return mysqli_affected_rows($conn);
    }
}*/
/*
function upload()
{
    $namaFile = $_FILES['gambar']['name'];
    $ukuranFile = $_FILES['gambar']['size'];
    $error = $_FILES['gambar']['error'];
    $tmpName = $_FILES['gambar']['tmp_name'];

    if ($error === 4) {
        echo "<script>alert('Pilih Gambar Dulu');</script>";
        return false;
    }

    $ekstensiGambarValid = array('jpg', 'jpeg', 'png');

    $ekstensiGambar = explode('.', $namaFile);
    $ekstensiGambar = strtolower(end($ekstensiGambar));

    if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
        echo "<script>alert('Gambar Tidak Sesuai');</script>";
        return false;
    }

    // Proses upload gambar
    move_uploaded_file($tmpName, 'uploads/' . $namaFile);

    return $namaFile;
}
if ($ukuranFile >1000000) {
	    echo "<script>alert('Gambar Terlalu Besar');</script>";
        return false;
}
*/
function cari($keyword)
{
    $query = "SELECT * FROM tb_warga
        WHERE
        nama LIKE '%$keyword%' OR
        alamat LIKE '%$keyword%' OR
        email LIKE '%$keyword%' OR
        kota LIKE '%$keyword%'
    ";
    return query($query);
}

?>
