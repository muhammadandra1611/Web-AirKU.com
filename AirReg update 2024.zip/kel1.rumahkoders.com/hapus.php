<?php
include('koneksi.php');
	  
// Periksa apakah parameter 'hapus' telah diterima melalui URL dan pastikan nilai adalah bilangan bulat
if(isset($_GET['hapus']) && is_numeric($_GET['hapus'])) {

    // Dapatkan nilai ID yang akan dihapus dari parameter URL
    $id = $_GET['hapus'];

    // Query untuk menghapus data dari tabel
    $query = $koneksi->prepare("DELETE FROM tb_warga WHERE id = ?");
    $query->bind_param("i", $id);

    // Jalankan query
    if($query->execute()) {
        // Jika berhasil dihapus, arahkan kembali ke halaman admin.php

        header("location: admin.php");
        exit; // Hentikan eksekusi script setelah redirect
    } else {
        // Jika gagal, tampilkan pesan error yang lebih deskriptif
        echo "Gagal menghapus data: " . $koneksi->error;
    }
} else {
    // Jika parameter 'hapus' tidak ditemukan atau tidak valid, tampilkan pesan error
    echo "Parameter 'hapus' tidak valid atau tidak ditemukan.";
}
// Periksa apakah parameter 'hapus' telah diterima melalui URL dan pastikan nilai adalah bilangan bulat
if(isset($_GET['hapus_tarif']) && is_numeric($_GET['hapus_tarif'])) {

    // Dapatkan nilai ID yang akan dihapus dari parameter URL
    $id = $_GET['hapus_tarif'];

    // Query untuk menghapus data dari tabel
    $query = $koneksi->prepare("DELETE FROM tb_tarif WHERE id = ?");
    $query->bind_param("i", $id);

    // Jalankan query
    if($query->execute()) {
        // Jika berhasil dihapus, arahkan kembali ke halaman admin.php

        header("location: bendahara.php?id=bendahara");
        exit; // Hentikan eksekusi script setelah redirect
    } else {
        // Jika gagal, tampilkan pesan error yang lebih deskriptif
        echo "Gagal menghapus data: " . $koneksi->error;
    }
} else {
    // Jika parameter 'hapus' tidak ditemukan atau tidak valid, tampilkan pesan error
    echo "Parameter 'hapus' tidak valid atau tidak ditemukan.";
}



if(isset($_GET['hapus_meter']) && is_numeric($_GET['hapus_meter'])) {

    // Dapatkan nilai ID yang akan dihapus dari parameter URL
    $id = $_GET['hapus_meter'];

    // Query untuk menghapus data dari tabel
    $query = $koneksi->prepare("DELETE FROM tb_meter WHERE id = ?");
    $query->bind_param("i", $id);

    // Jalankan query
    if($query->execute()) {
        // Jika berhasil dihapus, arahkan kembali ke halaman admin.php

        header("location: petugas.php?userr=data_pemakaian");
        exit; // Hentikan eksekusi script setelah redirect
    } else {
        // Jika gagal, tampilkan pesan error yang lebih deskriptif
        echo "Gagal menghapus data: " . $koneksi->error;
    }
} else {
    // Jika parameter 'hapus' tidak ditemukan atau tidak valid, tampilkan pesan error
    echo "Parameter 'hapus' tidak valid atau tidak ditemukan.";
}
?>
