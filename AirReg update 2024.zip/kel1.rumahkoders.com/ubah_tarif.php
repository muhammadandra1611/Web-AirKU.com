<?php
    
$koneksi=mysqli_connect("localhost","rumahko5_AirKu","Sepakbola123","rumahko5_kel1");
////////////////////////////////////////////////////////////////////////////////////////////////////
// Mengambil id dari URL
$ubah_tarif = $_GET["ubah_tarif"];

// var_dump($ubah_tarif);

// Memeriksa apakah form telah disubmit
if(isset($_POST["submit_tarif"])){
    $id_tarif = mysqli_real_escape_string($koneksi, $_POST["id_tarif"]);
    $tipe_tarif = mysqli_real_escape_string($koneksi, $_POST["tipe_tarif"]);
    $tarif = mysqli_real_escape_string($koneksi, $_POST["tarif"]);
    $status = mysqli_real_escape_string($koneksi, $_POST["status"]);

    // Query UPDATE untuk mengubah data berdasarkan id
    $query = "UPDATE tb_tarif SET id_tarif='$id_tarif', tipe_tarif='$tipe_tarif', tarif='$tarif', status='$status' WHERE id= $ubah_tarif";
    mysqli_query($koneksi, $query);

    echo "<script>
            alert('Data berhasil diubah');
            document.location.href='bendahara.php';
          </script>";
}

// Mengambil data tarif yang akan diubah
$query_data = "SELECT * FROM tb_tarif WHERE id=$ubah_tarif";
$result = mysqli_query($koneksi, $query_data);
$tr = mysqli_fetch_assoc($result);

// Memeriksa apakah data ditemukan
if (!$tr) {
    echo "<script>
            alert('Data tidak ditemukan');
            document.location.href='bendahara.php';
          </script>";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Ubah Data Tarif</title>
</head>
 <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input, select {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
            background-color: #ecf0f1; /* warna latar belakang */
            border: 1px solid #bdc3c7; /* warna border */
            border-radius: 4px;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
<body>

    <form action="" method="POST">
        <!-- Menambahkan nilai awal dari data yang akan diubah -->
        <label for="id_tarif">id_tarif:</label>
        <input type="text" id="id_tarif" name="id_tarif" value="<?php echo $tr['id_tarif']; ?>" required>

        <label for="tipe_tarif">tipe tarif:</label>
        <input type="text" id="tipe_tarif" name="tipe_tarif" value="<?php echo $tr['tipe_tarif']; ?>" required>

        <label for="tarif">tarif:</label>
        <input type="text" id="tarif" name="tarif" value="<?php echo $tr['tarif']; ?>" required>

        <label for="status">status:</label>
        <select class="form-select" aria-label="status" id="status" name="status">
            <option disabled selected>Pilih status</option>
            <option value="Aktif"<?php if ($tr['status'] == 'Aktif') echo ' selected'; ?>>Aktif</option>
            <option value="Tidak Aktif"<?php if ($tr['status'] == 'Tidak Aktif') echo ' selected'; ?>>Tidak Aktif</option>
        </select>

        <button type="submit" name="submit_tarif">Ubah</button>
    </form>
</body>
</html>

