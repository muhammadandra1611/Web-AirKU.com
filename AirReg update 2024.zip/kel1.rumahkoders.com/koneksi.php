<?php 
$server ="localhost";
$user ="rumahko5_AirKu";
$password="Sepakbola123";
$database="rumahko5_kel1";

$koneksi=mysqli_connect($server,$user,$password,$database) or die(mysqli_error($koneksi));

?>