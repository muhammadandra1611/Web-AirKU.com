<?php 
require 'koneksi.php';

session_start();

/*if (isset($_SESSION["username"])) {
  header("location:admin.php");

}*/

/*$q = "SELECT * FROM tuser WHERE username = '".$_SESSION['username']."'";
$l = mysqli_query($koneksi, $q);
$p = mysqli_fetch_assoc($l);
$id = $p["id"];*/

if (isset($_SESSION["username"]) && $_SESSION["username"] === "andra") {
  header("location: admin.php");
}elseif (isset($_SESSION["username"]) && $_SESSION["username"] === "petugas") {
  header("location: petugas.php");
}elseif (isset($_SESSION["username"]) && $_SESSION["username"] === "bendahara") {
  header("location: bendahara.php");
}elseif (isset($_SESSION["username"])) {
    /*  if ($id>=6) {*/
     header('location:warga.php?id='.$_SESSION["username"]);
      //  }

}








?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!--     <meta name="description" content="">
    <meta name="author" content=""> -->
    <link rel="icon" href="assets/img/favicons/recycling-water.png">

    <title>Login</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/dist/css/floating-labels.css" rel="stylesheet">
  </head>
  <style>

  </style>

  <body style="background-color:#87ceeb ">
    <form class="form-signin" method="POST" action="cek_login.php">
      <div class="text-center mb-4">
        <img class="mb-4" src="assets/img/favicons/recycling-water.png" alt="" width="72" height="72">
        <h1 class="h3 mb-3 font-weight-normal">AirKU.com</h1>
        <p>Silahkan login sesuai data yang telah di daftarkan <!-- <code>:placeholder-shown</code> pseudo-element. <a href="https://caniuse.com/#feat=css-placeholder-shown">Works in latest Chrome, Safari, and Firefox.</a></p> -->
  <?php if(isset($_GET["error"])){?>
  <div class="alert alert-danger" role="alert">
    User tidak ada!,silahkan hubungi 085156420506(admin)
  </div>
<?php } ?>
      <?php if(isset($_GET["pw"])){?>
       <div class="alert alert-danger" role="alert">
    Password yang Anda masukkan tidak sesuai
  </div>
      <?php } ?>
      </div>



      <div class="input-group mb-3">
        <input type="text"  name="username" class="form-control" placeholder="Masukkan Username Anda" required >
       
      </div>

      <div class="input-group mb-3">
        <input type="password"  name="password" class="form-control" placeholder="Masukkan Password Anda" required >
       
      </div>

<!--       <div class="form-label-group">
        <select class="form-control" name="level">
        <option value="admin">Admin</option>
        <option value="petugas">Petugas</option>
        <option value="bendahara">Bendahara</option>
        <option value="warga">Warga</option>
        </select>
      </div> -->
 <!--        <button class="button" onclick="changeBackground('lightcoral')">
            <img src="https://blog.indobot.co.id/wp-content/uploads/2020/11/10-1.jpg" width="100px" alt="Coral">
        </button>
        <button class="button" onclick="changeBackground('lightblue')">
            <img src="https://blog.indobot.co.id/wp-content/uploads/2020/11/10-1.jpg" width="100px" alt="Light Blue">
        </button>
        <button class="button" onclick="changeBackground('lightgreen')">
            <img src="https://blog.indobot.co.id/wp-content/uploads/2020/11/10-1.jpg" width="100px" alt="Light Green">
        </button> -->


      <div class="checkbox mb-3">
        <label>
          <input type="checkbox" value="remember-me"> Ingat saya
        </label>
      </div>
      <button class="btn btn-lg btn-primary btn-block" type="submit">Masuk</button>
   
      <p class="mt-5 mb-3 text-muted text-center">&copy; 2024-2025</p>

  </body>
<!--       <script>
        function changeBackground(color) {
            document.body.style.backgroundColor = color;
        }
    </script> -->
</html>
